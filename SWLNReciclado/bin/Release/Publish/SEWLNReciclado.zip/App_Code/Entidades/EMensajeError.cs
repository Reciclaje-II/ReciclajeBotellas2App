﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

/// <summary>
/// Descripción breve de EMensajeError
/// </summary>
/// 
[DataContract]
public class EMensajeError
{
    #region Propiedades

    #endregion

    #region Constructor

    public EMensajeError()
    {

    }

    #endregion
}